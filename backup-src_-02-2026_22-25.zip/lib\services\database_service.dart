import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:file_selector/file_selector.dart';
import 'package:path_provider/path_provider.dart';
import '../models/deposito.dart';
import '../utils/logger.dart';
import '../config/app_config.dart';

class DatabaseService {
  static Database? _database;
  static const String _dbName = AppConfig.dbName;
  static const int _dbVersion = AppConfig.dbVersion;

  // Tablas
  static const String depositosTable = 'depositos';
  static const String configTable = 'config';

  // Singleton
  DatabaseService._privateConstructor();
  static final DatabaseService instance = DatabaseService._privateConstructor();

  Future<Database> get database async {
    if (_database != null && _database!.isOpen) {
      return _database!;
    }
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), _dbName);

    return await openDatabase(
      path,
      version: _dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // Crear tabla de depósitos
    await db.execute('''
      CREATE TABLE $depositosTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL,
        ui_amount REAL NOT NULL,
        deposit_date TEXT NOT NULL,
        ui_value REAL NOT NULL,
        registration_date TEXT NOT NULL
      )
    ''');

    // Crear tabla de configuración
    await db.execute('''
      CREATE TABLE $configTable (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');

    // Insertar configuración por defecto
    await _insertDefaultConfig(db);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Para futuras actualizaciones
  }

  Future<void> _insertDefaultConfig(Database db) async {
    final defaultConfig = {
      'current_ui_value': AppConfig.defaultUiValue.toString(),
      'ui_source': 'Manual',
      'ui_last_update': DateTime.now().toIso8601String(),
      'formato_fecha': 'dd-MM-yyyy',
      'simbolo_moneda': '\$',
      'separador_miles': '.',
      'separador_decimal': ',',
      'decimales_ui': '4',
      'decimales_moneda': '2',
    };

    for (String key in defaultConfig.keys) {
      await db.insert(configTable, {'key': key, 'value': defaultConfig[key]!});
    }
  }

  // ===== OPERACIONES DE DEPÓSITOS =====

  Future<int> insertDeposito(Deposito deposito) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.insert(depositosTable, deposito.toMap());
    });
  }

  Future<List<Deposito>> getAllDepositos() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      depositosTable,
      orderBy: 'deposit_date DESC',
    );

    return List.generate(maps.length, (i) {
      return Deposito.fromMap(maps[i]);
    });
  }

  Future<Deposito?> getDepositoById(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      depositosTable,
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Deposito.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateDeposito(Deposito deposito) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.update(
        depositosTable,
        deposito.toMap(),
        where: 'id = ?',
        whereArgs: [deposito.id],
      );
    });
  }

  Future<int> deleteDeposito(int id) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.delete(depositosTable, where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<int> getDepositosCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) FROM $depositosTable');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  // ===== OPERACIONES DE CONFIGURACIÓN =====

  Future<String?> getConfig(String key) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      configTable,
      where: 'key = ?',
      whereArgs: [key],
    );

    if (maps.isNotEmpty) {
      return maps.first['value'] as String;
    }
    return null;
  }

  Future<void> setConfig(String key, String value) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.insert(
          configTable,
          {
            'key': key,
            'value': value,
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    });
  }

  Future<Map<String, String>> getAllConfig() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(configTable);

    Map<String, String> config = {};
    for (var map in maps) {
      config[map['key'] as String] = map['value'] as String;
    }
    return config;
  }

  // ===== MÉTODOS DE UTILIDAD =====

  Future<double> getTotalAmount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(amount) FROM $depositosTable');
    return (result.first.values.first as double?) ?? 0.0;
  }

  Future<double> getTotalUiAmount() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT SUM(ui_amount) FROM $depositosTable',
    );
    return (result.first.values.first as double?) ?? 0.0;
  }

  Future<double> getTotalCurrentValue(double currentUiValue) async {
    final depositos = await getAllDepositos();

    double total = 0.0;
    for (final deposito in depositos) {
      total += deposito.uiAmount * currentUiValue;
    }
    return total;
  }

  Future<double> getProfit(double currentUiValue) async {
    final totalAmount = await getTotalAmount();
    final totalCurrentValue = await getTotalCurrentValue(currentUiValue);
    return totalCurrentValue - totalAmount;
  }

  // ===== IMPORTACIÓN JSON =====

  Future<bool> importFromJson() async {
    try {
      AppLogger.i('Iniciando importFromJson con file_selector...');

      const typeGroup = XTypeGroup(
        label: 'JSON files',
        extensions: ['json'],
      );

      final file = await openFile(acceptedTypeGroups: [typeGroup]);

      if (file == null) {
        AppLogger.w('file_selector cancelado');
        return false;
      }

      AppLogger.i('Archivo seleccionado: ${file.name}');

      final path = file.path;
      if (path == null || path.isEmpty) {
        AppLogger.w('file_selector path es null o vacío');
        return false;
      }

      final jsonFile = File(path);
      if (!await jsonFile.exists()) {
        AppLogger.e('El archivo no existe: $path');
        return false;
      }

      AppLogger.i('Archivo existe, iniciando importación...');
      return await _importFromFile(jsonFile);
    } catch (e, stackTrace) {
      AppLogger.e('Error importando JSON: $e', e, stackTrace);
      return false;
    }
  }

  // Método para importación desde Android Download folder
  Future<bool> importFromJsonFixedPath() async {
    try {
      Directory? downloadsDir;
      if (Platform.isAndroid) {
        final externalDir = await getExternalStorageDirectory();
        if (externalDir != null) {
          downloadsDir = Directory(
              '${externalDir.parent.parent.parent.parent.path}/Download');
        }
      }

      if (downloadsDir == null) {
        throw Exception('No se pudo acceder al directorio de Downloads');
      }

      AppLogger.i('Buscando archivo en: ${downloadsDir.path}');
      final file = File('${downloadsDir.path}/bhu_datos.json');

      if (!await file.exists()) {
        throw Exception('Archivo JSON no encontrado en: ${file.path}');
      }

      return await _importFromFile(file);
    } catch (e) {
      AppLogger.e('Error importando JSON desde ruta fija', e);
      return false;
    }
  }

  // Importar desde string JSON (pegar directamente)
  Future<bool> importFromJsonString(String jsonString) async {
    try {
      AppLogger.i('Importando desde string JSON...');
      AppLogger.d('JSON string length: ${jsonString.length} caracteres');

      AppLogger.i('Parseando JSON...');
      final data = json.decode(jsonString) as Map<String, dynamic>;
      AppLogger.i('JSON parseado correctamente');

      AppLogger.i('Obteniendo conexión a base de datos...');
      final db = await database;
      AppLogger.i('Conexión establecida');

      AppLogger.i('Iniciando transacción...');
      await db.transaction((txn) async {
        AppLogger.i('Transacción iniciada - Limpiando depósitos existentes...');
        await txn.delete(depositosTable);
        AppLogger.i('Depósitos limpiados');

        AppLogger.i('Importando configuración UI...');
        await _importUiConfig(txn, data);
        AppLogger.i('Configuración UI importada');

        AppLogger.i('Importando depósitos...');
        await _importDepositosBatch(txn, data);
        AppLogger.i('Depósitos importados');
      });

      AppLogger.i('Transacción completada exitosamente');
      AppLogger.i('Importación exitosa desde string JSON');
      return true;
    } catch (e, stackTrace) {
      AppLogger.e('Error importando desde string JSON: $e', e, stackTrace);
      return false;
    }
  }

  // Método privado auxiliar para importar desde un archivo específico (refactorizado)
  Future<bool> _importFromFile(File file) async {
    Database? db;
    try {
      AppLogger.i('Leyendo archivo JSON: ${file.path}');
      final content = await file.readAsString();
      AppLogger.d('Contenido leído: ${content.length} caracteres');

      AppLogger.i('Parseando JSON...');
      final data = json.decode(content) as Map<String, dynamic>;
      AppLogger.i('JSON parseado correctamente');

      AppLogger.i('Obteniendo conexión a base de datos...');
      db = await database;
      AppLogger.i('Conexión establecida');

      AppLogger.i('Iniciando transacción...');
      await db.transaction((txn) async {
        AppLogger.i('Transacción iniciada - Limpiando depósitos existentes...');
        // Limpiar depósitos existentes
        await txn.delete(depositosTable);
        AppLogger.i('Depósitos limpiados');

        AppLogger.i('Importando configuración UI...');
        // Importar UI data
        await _importUiConfig(txn, data);
        AppLogger.i('Configuración UI importada');

        AppLogger.i('Importando depósitos...');
        // Importar depósitos en batch
        await _importDepositosBatch(txn, data);
        AppLogger.i('Depósitos importados');
      }).timeout(AppConfig.dbTimeout);

      AppLogger.i('Transacción completada exitosamente');
      AppLogger.i('Importación exitosa desde: ${file.path}');
      return true;
    } catch (e, stackTrace) {
      AppLogger.e('Error importando desde archivo: $e', e, stackTrace);
      return false;
    } finally {
      if (db != null) {
        AppLogger.i('Cerrando conexión a base de datos...');
        await db.close();
        _database = null;
        AppLogger.i('Conexión cerrada');
      }
    }
  }

  // Método privado para importar configuración UI
  Future<void> _importUiConfig(
    Transaction txn,
    Map<String, dynamic> data,
  ) async {
    if (data['ui_actual'] != null) {
      await txn.insert(
          configTable,
          {
            'key': 'current_ui_value',
            'value': data['ui_actual'].toString(),
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    if (data['ui_fuente'] != null) {
      String source = data['ui_fuente'].toString();
      if (source.contains('-') && source.contains('T')) {
        await txn.insert(
            configTable,
            {
              'key': 'ui_source',
              'value': 'DolarApi.com',
            },
            conflictAlgorithm: ConflictAlgorithm.replace);
        await txn.insert(
            configTable,
            {
              'key': 'ui_last_update',
              'value': source,
            },
            conflictAlgorithm: ConflictAlgorithm.replace);
      } else {
        await txn.insert(
            configTable,
            {
              'key': 'ui_source',
              'value': source,
            },
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
    }
    if (data['ui_ultima_actualizacion'] != null) {
      await txn.insert(
          configTable,
          {
            'key': 'ui_last_update',
            'value': data['ui_ultima_actualizacion'].toString(),
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  // Método privado para importar depósitos en batch
  Future<void> _importDepositosBatch(
    Transaction txn,
    Map<String, dynamic> data,
  ) async {
    if (data['depositos'] != null) {
      final depositosList = data['depositos'] as List;
      final batch = txn.batch();

      for (final depositoJson in depositosList) {
        batch.insert(depositosTable, {
          'amount': depositoJson['amount'],
          'ui_amount': depositoJson['ui_amount'],
          'deposit_date': depositoJson['deposit_date'],
          'ui_value': depositoJson['ui_value'],
          'registration_date': depositoJson['registration_date'],
        });
      }

      await batch.commit(noResult: true);
    }
  }

  // ===== RECUPERACIÓN DE BLOQUEOS =====

  Future<void> resetConnection() async {
    try {
      if (_database != null && _database!.isOpen) {
        await _database!.close();
      }
      _database = null;
    } catch (e) {
      AppLogger.e('Error reseteando conexión', e);
      _database = null;
    }
  }

  Future<bool> isLocked() async {
    try {
      final db = await database;
      await db.rawQuery('SELECT 1');
      return false;
    } catch (e) {
      if (e.toString().contains('locked')) {
        return true;
      }
      return false;
    }
  }

  Future<void> waitForUnlock({
    Duration timeout = AppConfig.dbTimeout,
  }) async {
    final stopwatch = Stopwatch()..start();

    while (stopwatch.elapsed < timeout) {
      if (!await isLocked()) {
        return;
      }
      await Future.delayed(const Duration(milliseconds: 500));
    }

    throw TimeoutException(
      'Base de datos bloqueada por más de ${timeout.inSeconds} segundos',
      timeout,
    );
  }

  // ===== LIMPIEZA =====

  Future<void> closeDatabase() async {
    try {
      if (_database != null && _database!.isOpen) {
        await _database!.close();
      }
      _database = null;
    } catch (e) {
      AppLogger.e('Error cerrando base de datos', e);
      _database = null;
    }
  }

  Future<void> deleteDatabase() async {
    try {
      await closeDatabase();
      final path = join(await getDatabasesPath(), _dbName);
      await databaseFactory.deleteDatabase(path);
    } catch (e) {
      AppLogger.e('Error eliminando base de datos', e);
      rethrow;
    }
  }

  // ===== EXPORTAR A CSV =====

  Future<File> exportToCsv(double currentUiValue) async {
    try {
      final depositos = await getAllDepositos();

      final buffer = StringBuffer();
      buffer.writeln('ID,Fecha,Monto (\$),UI,Valor UI,Valor Actual (\$)');

      for (final deposito in depositos) {
        final currentValue = deposito.uiAmount * currentUiValue;
        buffer.writeln(
          '${deposito.id},'
          '${deposito.depositDate},'
          '${deposito.amount.toStringAsFixed(2)},'
          '${deposito.uiAmount.toStringAsFixed(4)},'
          '${deposito.uiValue.toStringAsFixed(4)},'
          '${currentValue.toStringAsFixed(2)}',
        );
      }

      final directory = await getTemporaryDirectory();
      final timestamp = DateTime.now().toIso8601String().split('T')[0];
      final file = File('${directory.path}/bhu_depositos_$timestamp.csv');
      await file.writeAsString(buffer.toString());

      AppLogger.i('CSV exportado: ${file.path}');
      return file;
    } catch (e) {
      AppLogger.e('Error exportando CSV', e);
      rethrow;
    }
  }

  // ===== CREAR BACKUP =====

  Future<File> createBackup() async {
    try {
      final depositos = await getAllDepositos();
      final currentUiValue = await getConfig('current_ui_value') ??
          AppConfig.defaultUiValue.toString();
      final uiSource = await getConfig('ui_source') ?? 'Manual';
      final uiLastUpdate =
          await getConfig('ui_last_update') ?? DateTime.now().toIso8601String();

      final depositosList = depositos
          .map(
            (d) => {
              'id': d.id,
              'amount': d.amount,
              'ui_amount': d.uiAmount,
              'deposit_date': d.depositDate,
              'ui_value': d.uiValue,
              'registration_date': d.registrationDate,
            },
          )
          .toList();

      final backupData = {
        'ui_actual':
            double.tryParse(currentUiValue) ?? AppConfig.defaultUiValue,
        'ui_fuente': uiSource,
        'ui_ultima_actualizacion': uiLastUpdate,
        'depositos': depositosList,
      };

      final jsonString = const JsonEncoder.withIndent('  ').convert(backupData);

      final directory = await getTemporaryDirectory();
      final timestamp = DateTime.now().toIso8601String().split('T')[0];
      final file = File('${directory.path}/bhu_backup_$timestamp.json');
      await file.writeAsString(jsonString);

      AppLogger.i('Backup creado: ${file.path}');
      return file;
    } catch (e) {
      AppLogger.e('Error creando backup', e);
      rethrow;
    }
  }
}
