import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../utils/logger.dart';

class UrService {
  static const String _baseUrlDatosUruguay = 'https://datosuruguay.com';

  static Future<double> getUrValue() async {
    try {
      AppLogger.i('Obteniendo valor UR desde datosuruguay.com...');
      final response = await http.get(
        Uri.parse('$_baseUrlDatosUruguay/ur'),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept':
              'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      ).timeout(AppConfig.apiTimeout);

      AppLogger.i('Status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final html = response.body;
        AppLogger.i('HTML length: ${html.length}');

        final pricePattern = RegExp(
          r'Precio actual[:\s]*[\n\r\s]*UR\s*\$?([\d\.]+)',
          caseSensitive: false,
        );

        final match = pricePattern.firstMatch(html);
        AppLogger.i('Primer regex match: ${match?.group(0)}');

        if (match != null) {
          final priceStr = match.group(1)!.replaceAll('.', '');
          AppLogger.i('Valor extraido: ${match.group(1)} -> $priceStr');
          return double.parse(priceStr);
        }

        final pricePattern2 = RegExp(
          r'UR\s*\$\s*([\d\.]+)',
          caseSensitive: false,
        );

        final matches = pricePattern2.allMatches(html);
        for (var match in matches) {
          final priceStr = match.group(1)!.replaceAll('.', '');
          final price = double.parse(priceStr);
          if (price > 1000) {
            AppLogger.i('Segundo regex match: $price');
            return price;
          }
        }
      }

      return AppConfig.defaultUrValue;
    } catch (e) {
      AppLogger.e('Error fetching UR value', e);
      return AppConfig.defaultUrValue;
    }
  }

  static Future<Map<String, dynamic>> getAllValues() async {
    try {
      AppLogger.i('getAllValues() llamado...');
      final response = await http.get(
        Uri.parse('$_baseUrlDatosUruguay/ur'),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept':
              'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      ).timeout(AppConfig.apiTimeout);

      AppLogger.i('getAllValues Status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final html = response.body;
        AppLogger.i('getAllValues HTML length: ${html.length}');

        double urValue = AppConfig.defaultUrValue;
        final pricePattern = RegExp(
          r'Precio actual[:\s]*[\n\r\s]*UR\s*\$?([\d\.]+)',
          caseSensitive: false,
        );

        final match = pricePattern.firstMatch(html);
        AppLogger.i('getAllValues primer regex match: ${match?.group(0)}');

        if (match != null) {
          final priceStr = match.group(1)!.replaceAll('.', '');
          urValue = double.parse(priceStr);
          AppLogger.i(
              'getAllValues valor extraido: ${match.group(1)} -> $priceStr');
        } else {
          final pricePattern2 = RegExp(
            r'UR\s*\$\s*([\d.]+)',
            caseSensitive: false,
          );

          final matches2 = pricePattern2.allMatches(html);
          AppLogger.i('getAllValues segundo regex matches: ${matches2.length}');

          for (var m in matches2) {
            final priceStr = m.group(1)!.replaceAll('.', '');
            final price = double.tryParse(priceStr) ?? 0;
            AppLogger.i('getAllValues probando valor: $price');
            if (price > 1000 && price < 10000) {
              urValue = price;
              AppLogger.i(
                  'getAllValues valor encontrado con segundo regex: $price');
              break;
            }
          }
        }

        return {
          'ur': urValue,
          'source': 'datosuruguay.com',
          'lastUpdate': DateTime.now().toIso8601String(),
        };
      } else {
        AppLogger.w('getAllValues status no es 200: ${response.statusCode}');
      }

      AppLogger.w(
          'getAllValues retornando valor por defecto: ${AppConfig.defaultUrValue}');
      return {
        'ur': AppConfig.defaultUrValue,
        'source': 'datosuruguay.com',
        'lastUpdate': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      AppLogger.e('Error fetching UR values', e);
      return {
        'ur': AppConfig.defaultUrValue,
        'source': 'datosuruguay.com',
        'lastUpdate': DateTime.now().toIso8601String(),
      };
    }
  }
}
